package com.example.StudentCourseProject.Student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.stereotype.Controller;


@Controller
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/sHome")
    public String Home(){
        return "studentHome.html";
        
    }

    @GetMapping("/students")
    public Iterable<Student> getAllStudents(){
        return studentService.getAllStudents();

    }

    @GetMapping("/students/{studentId}")
    public void getStudent(@PathVariable String studentId){
           studentService.getStudent(studentId);
    }
    
    @PostMapping("/students")
    public void addStudent(@RequestBody Student students){
        studentService.addStudent(students);
    }

    // @PutMapping("/students/{studentId}")
    // public void updateStudent(@RequestBody Student student, @PathVariable String studentId){
    //     studentService.updateStudent(studentId, student);
    // }
    @DeleteMapping("/students/{studentId}")
    public void deleteStudent(@PathVariable String studentId){
        studentService.deleteStudent(studentId);
    }

}
