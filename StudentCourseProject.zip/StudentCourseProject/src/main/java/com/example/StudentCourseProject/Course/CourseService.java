package com.example.StudentCourseProject.Course;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CourseService {

    @Autowired
    private  CourseRepository courseRepository;
    
 private  List<Course> courses = new ArrayList<>(Arrays.asList(
                        // new Course(null, "Java", "100", 11)
//                      new Course("AWS", "200", 12),
//                      new Course("HTML", "300", 13),
//                      new Course("CSS", "400", 14)
        ));
 
    public  List<Course> getAllCourses(){

       // List<Course> courses = new ArrayList<>();
       return courseRepository.findAll();

        /*for (Course course : courses) {
            
            courses.add(course);
        }
        return courses;*/
    }
     public Course getCourse(String courseId){
    //    //return  course.stream().filter( t -> t.getCourseId() == courseId).collect(Collectors.toList());

        return courseRepository.getReferenceById(courseId);
     }
    public void addCourse(Course course) {
        //courses.add(course);
        courseRepository.save(course);

    }
    public void updateCourse(int courseId, Course course) {

        // for(int i=0; i<courses.size(); i++)
        // {
        //     Course c = courses.get(i);
        //     if (c.getCourseId()==(courseId)){
        //         courses.set(i, course);
                
        //     }
        // }
            courseRepository.save(course);
}
     public void deleteCourse(String courseId) {
         //courses.removeIf(t -> t.getCourseId()==courseId);
         courseRepository.deleteById(courseId);
     }

 
}
