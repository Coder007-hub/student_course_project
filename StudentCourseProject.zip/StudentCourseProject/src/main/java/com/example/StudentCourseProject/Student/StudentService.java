package com.example.StudentCourseProject.Student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    
   public static  List<Student> student = new ArrayList<>(Arrays.asList(
            //    new Student("Shiva", "23 Orange st, Fitchburg, Massachusetts", "11", "100")
            //    new Student("Ganesh", "816 Crest Village Dr, Georgia", "12", "200"),
            //    new Student("Sai", "100 Houston, Texas", "13", "300"),
            //    new Student("Surya", "355 Times Square, New York", "14", "400")
        ));

    public List<Student> getAllStudents(){
        
           return studentRepository.findAll();
       
        
   
    }    

    public Optional<Student> getStudent(String studentId){
       //return  student.stream().filter( s -> s.getStudentId() == studentId).collect(Collectors.toList());
       //return student.get(studentId);

        return studentRepository.findById(studentId);
   //  return null;

    }

    @SuppressWarnings("null")
    public void addStudent(Student student) {
       //student.add(students);

       studentRepository.save(student);
    }

    public void updateStudent(String studentId, Student student2) {
        // for(int i=0;i<student.size(); i++){
        //     Student s=student.get(i);
        //     if (s.getStudentId()==(studentId)){
        //         student.set(i, student2);
                
        //     } 
        // }
         studentRepository.save(student2);
        
    }

        public void deleteStudent(String studentId) {

     //      student.removeIf(s -> s.getStudentId() == studentId);
    //     studentRepository.deleteById(studentId);
    studentRepository.deleteById(studentId); 
    }

}
