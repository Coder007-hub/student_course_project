package com.example.StudentCourseProject.Course;


import java.util.ArrayList;
import java.util.List;
import com.example.StudentCourseProject.Student.Student;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Course")
public class Course {

   @JsonIgnore
   @OneToMany(mappedBy="courseId")
   private List<Student> student = new ArrayList<Student>();

   
   @Column(name = "coursename")
   private String coursename;

   @Id
   @Column(name = "courseId")
   private String courseId;
    

   @Column(name = "studentId")
   private String studentId;
}
